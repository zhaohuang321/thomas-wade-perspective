蒸馏流程参考 [女娲 · Skill造人术](https://github.com/alchaincyf/nuwa-skill)，创建者花叔。第三方流程许可见 THIRD_PARTY_LICENSES/nuwa-skill-LICENSE。该许可不代表小说、人物或本仓库所有内容获得统一授权。具体资料来源见调研笔记。

本项目是文学分析与方法整理，包含剧透。原著事实、研究解释和现实推断应分别判断；不是刘慈欣或原著人物的官方立场。
